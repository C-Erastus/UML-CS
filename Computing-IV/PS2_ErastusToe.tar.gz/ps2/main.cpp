#include <iostream>

int main(){

	std::cout << "My work is still in progress" << std::endl; 

	return 0;
}
