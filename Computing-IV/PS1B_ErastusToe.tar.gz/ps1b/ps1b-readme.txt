/**********************************************************************
 *  Linear Feedback Shift Register (part B) ps1b-readme.txt template
 **********************************************************************/

Name: C. Erastus Toe
OS: Linux Ubuntu
Machine (e.g., Dell Latitude, MacBook Pro): Dell
Text editor: Vim & VS code
Hours to complete assignment: 2
/**********************************************************************
 *  Briefly discuss the assignment itself and what you accomplished.
 **********************************************************************/
Using our LFSR class I was supposed to encode and decode images using 
the XOR operator. And using the the return  value of the generate function




/**********************************************************************
 *  If you did any implementation for extra credit, describe it
 *  here and why it is interesting.
 **********************************************************************/




/**********************************************************************
 *  List whatever help (if any) you received from the instructor,
 *  classmates, or anyone else.
 **********************************************************************/
Chris ODOM ---> I had some help from chris. He explained the assignment
to me. 

/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
I just got a little confused on how I was suppoded to decode the images
but the example code helped a lot 

/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/

I wished the assignment was better explained 
